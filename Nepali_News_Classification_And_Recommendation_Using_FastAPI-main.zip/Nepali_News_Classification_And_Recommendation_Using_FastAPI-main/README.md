# FastAPI Nepali News Classification Web Application Preview
![Webapp](2.png)

# FastAPI Nepali News Recommendation Perview
![recommendation](recommendation.png)
